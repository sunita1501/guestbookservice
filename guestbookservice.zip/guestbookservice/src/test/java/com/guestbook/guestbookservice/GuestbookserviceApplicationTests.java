package com.guestbook.guestbookservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuestbookserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
